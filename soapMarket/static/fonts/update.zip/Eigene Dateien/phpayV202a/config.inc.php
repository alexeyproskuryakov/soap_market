<?php
## Config        
$version = "2.02";
$order_mail = "order@phpay.de"; // Empf&auml;nger der Bestell-Emails
$shop_mail = "shop@phpay.de";   // Absender aller Emails
$mailcheck = "1";   // &Uuml;berpr&uuml;fung der Kunden-Emailadresse
$bgcolor1 = "#EEEEEE";    //  Hintergrundfarbe
$bgcolor2  = "#000000";   // Textfarbe
$bgcolor3 = "#220000";    // Kopfzeilen- &amp; Link-Farbe
$bgcolor4 = "#553355";    // Tabellenhintergrund &amp; vlink
$aacolor = "#FF0000";      // Aktivierte Links
$bgform = "#F7F7F7";        // Hintergrund f&uuml;r Formulare
$logo = "img/phPayV2.gif";             // Logo (Bilddatei)
$site_name = "phPay 2.0";   // Name oberhalb der Navigation
$site_title = "phPay - Demo in action."; // Fenstertitel
$hp_url = "http://www.sourceforge.net/projects/phpay";         // URL der Homepage (nach &quot;Shop verlassen&quot;)
$nav_width = "165";   // Breite der Navigationsleiste
$nav_horiz = "0";   // Richtung der Navigation
$tree = "2";     	   // Artikelgruppen als Baum in der [ 1 | 2 ]
$show_null = "0";   // Preise zeigen, die 0.00 sind
$clg = "0";	// 2: catalog with wishlist
	// 1: system works as catalog without prices, cart and users
	// 0: system works as shop with cart, prices and users
$chg_lang = "1";     // Benutzer kann Sprache ausw&auml;hlen [ 0 | 1 ]
$chg_cur = "0";       // Benutzer kann W�hrung ausw�hlen [ 0 | 1 ]
$automail = "1";     // Automatische Best&auml;tigung an Kunden [ 0 | 1 ]
$max_item = "20";     // Maximale St&uuml;ckzahl pro Artikel
$showcart = "right";     // Warenkorb [ left | right ]
$litems = "show_item_0.inc.php";         // Anzeigedatei
$view_limit = "20"; // Artikel pro Seite
$psm_cursym = "Euro"; // W�hrung f�r Versand- und Bezahlarten
$use_stock = "1"; // Verf�gbarkeit anzeigen [ 0 | 1 ]
$auto_convert = "1"; // W�hrung automatisch umrechnen [ 0 | 1 ]
$dflt_lang=1;
$dflt_cur=1;

 ?>