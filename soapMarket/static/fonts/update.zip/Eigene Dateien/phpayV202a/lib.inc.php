<?php
if (ereg("lib.inc.php", $SCRIPT_NAME)) header("Location:./index.html");
elseif (ereg("lib.inc.php", $_SERVER['SCRIPT_NAME'])) header("Location:./index.html");
$result = db_query("select user_ID, user_pw, langID, config, curID from online where session='$sess'") or db_die();
$row = db_fetch_row($result);
if (!isset($dflt_lang))
{
  $dflg_res = db_query("SELECT MIN(ID) FROM language") or db_die();
  $dflg_row = db_fetch_row($dflg_res);
  $dflt_lang = $dflg_row[0];
}
$langID = $row[2];
if ($langID==0) { $langID = $dflt_lang; }
$lang_res = db_query("select shortt from language where ID='$langID'") or db_die();
if (db_num_rows($lang_res)==0)
{
  $langID = $dflt_lang;
  $lang_res = db_query("select shortt from language where ID='$langID'") or db_die();
}
$lang_row = db_fetch_row($lang_res);
$lang = $lang_row[0];
if (file_exists("./lang/$lang.inc.php")) include("./lang/$lang.inc.php");
else exit("Language error $lang . $langID . $dflt_lang</table></body></html>\n");
$config = $row[3];
$curID = $row[4];
$cur_res = db_query("select keysign from currency where ID='$curID'") or db_die();
$cur_row = db_fetch_row($cur_res);
if ($cur_row[0]==0){
  $cur_res = db_query("select keysign from currency where ID='$dflt_cur'") or db_die();
  $cur_row = db_fetch_row($cur_res);
}
$cursym = $cur_row[0];
$file = fopen ("./$row[3]", "r");
$i=0;
while ($i<32) {
  $line = fgets ($file, 200);
  $i++;
}
$line = fgets ($file, 200);
$auto_convert=substr($line,17,1);
fclose($file);

$result2 = db_query("select * from user where kdnr='$row[0]' and pw='$row[1]'") or db_die();
$row2 = db_fetch_row($result2);
$user_ID = $row2[0];
$user_firstname = $row2[1];
$user_name = $row2[2];
$md_pw= $row2[3];
$user_group = $row2[4];
$user_email = $row2[5];
$user_kdnr = $row2[7];

$netto_res = db_query("select usrgroup.bn from usrgroup where usrgroup.ID='$row2[4]'") or db_die();
$netto_row = db_fetch_row($netto_res);
$user_pt = $netto_row[0];   # can be 0 -> called 'netto' without VAT
                            # can be 1 -> VAT included

$pt_res = db_query("select vat from pricetype where ID=1") or db_die();
$pt_row = db_fetch_row($pt_res);
$vat = ($pt_row[0]-1)*100;
$vatconv = $pt_row[0];

$dis_res = db_query("select discount from usrgroup where ID='$user_group'") or db_die();
$dis_row = db_fetch_row($dis_res);
$user_disc = $dis_row[0]/100;

?>
