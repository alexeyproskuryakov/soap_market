<?php
$url = "curr.php";
require("header.inc.php");
echo "<table border=0 cellpadding=6 cellspacing=2 align=center width=500>\n";
echo "<tr bgcolor='$bgcolor3'><td colspan=5 align=center><font color='$bgcolor1'>$admin_10</font>";
echo "<a href=\"help.php?langID=$langID#currency\" target=\"besite\"><img src=\"help.gif\" border=0 align=absmiddle></a>\n";
echo "</td></tr>\n";
echo "</table>\n";
$nrate = ereg_replace(",",".",$nrate);
if ($mode=="Add") { db_query("insert into currency values('%','$nkeysign','$nname','$nrate','')");}
elseif ($mode=="Edit") {
  if ($ID==1) { $nrate=1; }
  db_query("update currency set keysign='$nkeysign', name='$nname', rate='$nrate' where ID='$ID'");
}
elseif ($mode=="Delete") {
  db_query("delete from currency where ID='$ID'");
  db_query("delete from price where curID='$ID'");
}
$curr_res = db_query("select * from currency") or db_die();
echo "<table border=0 cellpadding=6 cellspacing=2 align=center>\n";
echo "<tr valign=top align=center><td>$curr_1</td><td>$curr_2</td><td>$curr_3</td><td>$curr_4</td><td>&nbsp;</td>\n</tr>\n";
echo "<form action=$url method=post><tr><td>$curr_5:</td>\n";
echo "<td><input type=text name=nkeysign maxlength=3 size=5></td>\n";
echo "<td><input type=text name=nname></td>\n";
echo "<input type=hidden name=langID value=\"$langID\"></td>\n";
echo "<td><input type=text name=nrate size=15></td>\n";
echo "<td><input type=submit value=\"Add\" name=mode></td></tr></form>\n";
while ($curr_row = db_fetch_row($curr_res)) {
  echo "<form action=\"$url\" method=\"post\"><tr><td><input type=hidden value=\"$curr_row[0]\" name=ID>$curr_row[0]</td>\n";
  echo "<td><input type=text value=\"$curr_row[1]\" name=nkeysign maxlength=3 size=5></td>\n";
  echo "<td><input type=text value=\"$curr_row[2]\" name=nname>\n";
  echo "<input type=hidden name=langID value=\"$langID\"></td>\n";
  echo "<td><input type=text value=\"$curr_row[3]\" name=nrate size=15></td>\n";
  echo "<td><input type=submit value=\"Edit\" name=mode>\n";
  if ($curr_row[0]!=1) { echo "<input type=submit value=\"Delete\" name=mode>"; }
  echo "</td></tr></form>\n";
}
echo "<tr><td colspan=5>$curr_6: <a href=\"http://www.ecb.int/stats/eurofxref/\" target=outside>$curr_7 .</a></td></tr>\n";
echo "\n</table>\n<body>\n</html>";
?>
