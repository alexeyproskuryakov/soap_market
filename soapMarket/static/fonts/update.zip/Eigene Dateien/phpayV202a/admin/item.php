<?php //ge&auml;ndert upload f&uuml;r sourceforge
$url = "item.php";
$view_limit=25;
require("header.inc.php");
echo "<table border=0 cellpadding=6 cellspacing=2 align=center width=500>\n";
echo "<tr bgcolor='$bgcolor3'><td colspan=5 align=center><font color='$bgcolor1'>$admin_4</font></td></tr>\n";
echo "</table>\n";
$nquanti = ereg_replace(",",".",$nquanti);
settype($nquanti, "double");
$nstock = ereg_replace(",",".",$nstock);
settype($nstock, "double");

if ($mode=="new") {
  $newid=time()+rand();
  if ($nquanti==0 || $nquanti!="") { $nquanti=1; }
  $upd_res = db_query("insert into item values('%','$nart_nr','$nartgr','$nkeyw','','','$nquanti','$newid','$norderby','$nvisible','$npackID','$nvatID')") or db_die();
  $new_res=db_query("select ID from item where newid='$newid'") or db_die();
  $new_row=db_fetch_row($new_res);
  if (is_uploaded_file("$npic[0]") && $npic_name[0]!="") {
  if (move_uploaded_file("$npic[0]","../images/$npic_name[0]")) {
    echo "$npic_name[0] ($npic_size[0], $npic_type[0]) uploaded :-)<br>\n";
    $upd_res = db_query("update item set picname1='$npic_name[0]' where ID='$new_row[0]'");}
  else {echo "$admin_24 $npic_name[0] ($npic[0], $npic_size[0], $npic_type[0]) :-(<br>\n";}
  }
  if (is_uploaded_file("$npic[1]") && $npic_name[1]!="") {
  if (move_uploaded_file("$npic[1]","../images/$npic_name[1]")) {
    echo "$npic_name[1] ($npic_size[1], $npic_type[1]) uploaded :-)<br>\n";
    $upd_res = db_query("update item set picname2='$npic_name[1]' where ID='$new_row[0]'");}
  else {echo "$admin_24 $npic_name[1] ($npic[1], $npic_size[1], $npic_type[1]) :-(<br>\n";}
  }

  $lang_res = db_query("select ID from language order by ID") or db_die();
  $i=0;
  while ($lang_row = db_fetch_row($lang_res)) {
    if ($nname[$i] != "") {
      $upd_res = db_query("insert into iteminfo values('%','$new_row[0]','$lang_row[0]','$nname[$i]','','$nlongdescr[$i]','')") or db_die();
    }
    $i++;
  }
  $i=0;
  while ($ncurID[$i]) {
    $npreis[$i] = ereg_replace(",",".",$npreis[$i]);
    settype($npreis[$i], "double");
    if ($vatvalue=="1") { $npreis[$i] = $npreis[$i]/$vat ; }
    $upd_res = db_query("insert into price values('%','$new_row[0]', '$langID', '$ncurID[$i]', '1', '$npreis[$i]')") or db_die();
    $i++;
  }
  if ($nstock=="") {$nstock==0;}
 $upd_res = db_query("insert into size values('%','$new_row[0]', '$nstock', '$nexpi' , '0' , '0' , '0')") or db_die();
  echo "&middot; $admin_22 $nart_nr ($nname[0]) $admin_23<br>\n";

}
elseif ($mode=="edit") {
  if ($nquanti==0) { $nquanti=1; }
  $upd_res = db_query("update item set number='$nart_nr', item.itemgrID='$nartgr', keywords='$nkeyw', quantity='$nquanti', orderby='$norderby', visible='$nvisible', item.packID='$npackID', vatID='$nvatID' where ID='$art'") or db_die();
  if (is_uploaded_file("$npic[0]")&&$npic_name[0]!="") {
    if (move_uploaded_file("$npic[0]","../images/$npic_name[0]")) {
      echo "$npic_name[0] ($npic_size[0], $npic_type[0]) uploaded.:-)<br>\n";
      $upd_res = db_query("update item set picname1='$npic_name[0]' where ID='$art'") or db_die();
    }
    else {echo "$admin_24 $npic_name[0] ($npic[0], $npic_size[0], $npic_type[0]) :-(<br>\n";  }
  }
  if (is_uploaded_file("$npic[1]") && $npic_name[1]!="") {
    if (move_uploaded_file("$npic[1]","../images/$npic_name[1]")) {
      echo "$npic_name[1] ($npic_size[1], $npic_type[1]) uploaded :-)<br>\n";
      $upd_res = db_query("update item set picname2='$npic_name[1]' where ID='$art'") or db_die();
    }
    else {echo "$admin_24 $npic_name[1] ($npic[1], $npic_size[1], $npic_type[1]) :-(<br>\n";  }
  }
  if ($picdel0==1) { $upd_res = db_query("update item set picname1='' where ID='$art'") or db_die(); }
  if ($picdel1==1) { $upd_res = db_query("update item set picname2='' where ID='$art'") or db_die(); }

  $lang_res = db_query("select ID from language order by ID") or db_die();
  $upd_res = db_query("delete from iteminfo where iteminfo.itemID='$art'") or db_die;
  $i=0;
  while ($lang_row = db_fetch_row($lang_res)) {
    if ($nname[$i] != "") {
      $upd_res = db_query("insert into iteminfo values ('%','$art','$lang_row[0]','$nname[$i]','','$nlongdescr[$i]','')") or db_die();
    }
    $i++;
  }

  $upd_res = db_query("delete from price where price.itemID='$art'");
  $i=0;
  while ($ncurID[$i]) {
    $npreis[$i] = ereg_replace(",",".",$npreis[$i]);
    settype($npreis[$i], "double");
    if ($vatvalue=="1") { $npreis[$i] = $npreis[$i]/$vat ; }
    if ($npreis[$i]==number_format($db_preis[$i],2)) {$npreis[$i]=$db_preis[$i];}
    $upd_res = db_query("insert into price values('%','$art', '$langID', '$ncurID[$i]', '1', '$npreis[$i]')"); $i++;
  }
  $upd_res = db_query("update size set stock='$nstock', expiration='$nexpi' where size.itemID='$art' and newid='0'") or db_die();

  echo "&middot; $admin_22 $nart_nr ($nname[0]) $admin_25<br>\n";
}
elseif ($mode=="del") {
  $size_res = db_query("select ID from size where size.itemID='$art'") or db_die();
  while ($size_row=db_fetch_row($size_res)) {
    $del0a_res = db_query("delete from size where ID='$size_row[0]'") or db_die();
    $del0b_res = db_query("delete from sizeinfo where sizeinfo.sizeID='$size_row[0]'") or db_die();
  }
  $color_res = db_query("select ID from color where color.itemID='$art'") or db_die();
  while ($color_row=db_fetch_row($color_res)) {
    $del1a_res = db_query("delete from color where ID='$color_row[0]'") or db_die();
    $del1b_res = db_query("delete from colorinfo where colorinfo.colorID='$color_row[0]'") or db_die();
  }
  $del2_res = db_query("delete from price where price.itemID='$art'") or db_die();
  $del3_res = db_query("delete from iteminfo where iteminfo.itemID='$art'") or db_die();
  $del4_res = db_query("delete from item where ID='$art'") or db_die();
}

if ($chg=="addnew") {
  $min_abt_res = db_query("select min(ID) from abt") or db_die();
  $min_abt_row = db_fetch_row($min_abt_res);
  $artgr_res = db_query("select itemgr.ID, itemgrinfo.name from itemgr, itemgrinfo where itemgrinfo.langID='$langID' and itemgr.ID = itemgrinfo.itemgrID and itemgr.abtID='$min_abt_row[0]'") or db_die();
  $abt_res = db_query("select abt.ID, abtinfo.name from abt, abtinfo where abtinfo.langID='$langID' and abt.ID = abtinfo.abtID") or db_die();
  $cur_res = db_query("select * from currency") or db_die();
  echo "<form action=\"$url\" enctype=\"multipart/form-data\" method=\"post\">\n<input type=hidden name=mode value=\"new\">\n";
  echo "<input type=hidden name=langID value=\"$langID\">\n";
  echo "<input type=hidden name=startlimit value=\"$startlimit\">\n";
  echo "<input type=hidden name=sort value=\"$sort\">\n";
  echo "<table border=0 cellpadding=6 cellspacing=2 align=center>\n";

  echo "<tr><td>$item_1</td><td colspan=3><input type=text name=nart_nr></td></tr>\n";
  $autofill=5;
  $lang_res = db_query("select ID,shortt from language order by ID") or db_die();
  while ($lang_row = db_fetch_row($lang_res)) {
    echo "<tr><td>$item_2 [$lang_row[1]]</td><td colspan=3><input type=text size=\"30\" name=\"nname[]\" value=\"\">\n";
    if ($autofill==5) {
      echo "<a href=\"javascript:autofill($autofill)\">autofill</a>\n";
      echo "&nbsp;&nbsp;&nbsp;<a href=\"help.php?langID=$langID#autofill\" target=\"besite\"><img src=\"help.gif\" border=0 align=\"absmiddle\"></a>\n";
    }
    echo "</td>\n";
    echo "</tr>\n";
    echo "<tr><td>$item_3 [$lang_row[1]]";
    if ($lang_row[0]==1) {
      echo " <a href=\"help.php?langID=$langID#dynsess\" target=\"besite\"><img src=\"help.gif\" border=0 align=\"absmiddle\"></a>\n";
    }
    echo "</td><td colspan=3><textarea cols=\"60\" rows=\"4\" name=\"nlongdescr[]\"></textarea></td></tr>\n";
    $autofill=$autofill+2;
  }
  echo "<script language=\"JavaScript\">\n";
  echo "function autofill(w) {\n";
  $autofill = $autofill-5;
  echo "  for (langlen=2; langlen<$autofill; langlen=langlen+2) {\n";
  echo "    document.forms[0].elements[w+langlen].value = document.forms[0].elements[w].value;\n";
  echo "  }\n}\n";
  echo "</script>\n";

  echo "<tr><td>$item_4</td><td colspan=3><input type=text name=nkeyw size=60>\n";
  echo "<a href=\"help.php?langID=$langID#keywords\" target=\"besite\"><img src=\"help.gif\" border=0></a>\n";
  echo "</td></tr>\n";
  while ($cur_row = db_fetch_row($cur_res))
{
    echo "<tr><td>";
    if ($cur_row[0]==1) {
      echo "$item_5&nbsp;&nbsp;&nbsp;\n";
      echo "<a href=\"help.php?langID=$langID#price\" target=\"besite\"><img src=\"help.gif\" border=0 align=\"absmiddle\"></a>\n";
    }
    echo "</td><td colspan=3><input type=text name=\"npreis[]\" size=6>\n";
    echo "<input type=hidden name=\"ncurID[]\" value=\"$cur_row[0]\">$cur_row[1]\n";
    if ($cur_row[0]==1) {
      echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type=checkbox name=\"vatvalue\" value=\"1\">$item_6";
      echo "<select name=\"vat\">\n";
      $pt_res = db_query("select vat from pricetype where vat>1") or db_die();
      while ($pt_row = db_fetch_row($pt_res)) {
        $vat = ($pt_row[0]-1)*100;
        echo "<option value=\"$pt_row[0]\">$vat %</option>\n";
      }
    }
    if ($cur_row[0]==2) {
      echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href=\"javascript:autoconvert()\">autoconvert</a>&nbsp;&nbsp;&nbsp;";
      echo "<a href=\"help.php?langID=$langID#autoconvert2\" target=\"besite\"><img src=\"help.gif\" border=0 align=\"absmiddle\"></a>\n";
      echo "<script language=\"JavaScript\">\n";
      $curr2_res = db_query("select rate from currency") or db_die();
      $curr2_len = db_num_rows($curr2_res);
      $lang_len = db_num_rows($lang_res);
      echo "var jscurr_start = 10 + ($lang_len*2);\n";
      echo "var jscurr = new Array($curr2_len);\n";
      $i=0;
      while ($curr2_row = db_fetch_row($curr2_res)) {
        echo "jscurr[$i]=$curr2_row[0];\n";
        $i++;
      }
      echo "function autoconvert() {\n";
      echo "  i=0;\n";
      echo "  jsprvalue= String(document.forms[0].elements[14].value);\n";
      echo "  jsprvalue= jsprvalue.replace(/,/ ,\".\");\n";
      echo "  jscurr_base = Math.round(parseFloat(jsprvalue)*100)/100;\n";
      echo "  for (x=1; x < $curr2_len; x++) {\n";
      echo "    w = jscurr_start +i;\n";
      echo "    jscv = Math.round(jscurr_base * jscurr[x]*100)/100;\n";
      echo "    document.forms[0].elements[w].value = jscv;\n";
      echo "    i=i+2;\n";
      echo "  }\n}\n";
      echo "</script>\n";
    }
    echo "</td></tr>\n";
  }
  echo "<tr><td>$item_7</td><td><input typ=text name=nquanti value=\"1\" size=6>&nbsp;\n";
  echo "<select name=\"npackID\">\n";
  $pack_res = db_query("select package.ID, packinfo.name from package,packinfo
              where package.ID = packinfo.packID and packinfo.langID='$langID' order by packinfo.name") or db_die();
  while ($pack_row = db_fetch_row($pack_res)) {
      echo "<option value='$pack_row[0]'>$pack_row[1]</option>\n";
  }
  echo "</select></td>\n";
  echo "<td>Mehrwertsteuergruppe</td>\n";
  echo "<td><select name=\"nvatID\">\n";
  $pt_res = db_query("select ID, vat from pricetype where vat>1") or db_die();
  while ($pt_row = db_fetch_row($pt_res)) {
    $vat = ($pt_row[1]-1)*100;
    echo "<option value=\"$pt_row[0]\">$vat %</option>\n";
  }
  echo "</td><tr>\n";

  echo "<tr><td>$item_8</td><td><input type=text name=norderby size=5></td>\n";
  echo "<td>$item_9</td><td><input type=checkbox name=nvisible value=1 checked></td>\n";
  echo "</tr>\n";

  echo "<tr><td>$item_10</td>\n";
  echo "<td><input type=text name=\"nstock\" size=10></td>\n";
  echo "<td><select name=\"nexpi\">\n";
  echo "<option value=\"actual\">2-3 Tage</option>\n<option value=\"Xactual\">2-3 Wochen</option>\n<option value=\"rest\">bis ausverkauft</option>\n";
  echo "<option value=\"never\" selected>immer</option>\n</select></td>\n";
  echo "<td><a href=\"help.php?langID=$langID#verf\" target=\"besite\"><img src=\"help.gif\" border=0></a></tr>\n";

  echo "<tr><td>$item_14</td><td><input type=\"file\" name=\"npic[]\" accept=\"image/*\"></td>\n";
  echo "<td>$item_15</td><td><input type=\"file\" name=\"npic[]\" accept=\"image/*\"></td></tr>\n";

  echo "<tr><td>$admin_2</td>\n";
  echo "<td><select name=nabt onchange=\"updateArtgr(this.form, this.options[this.selectedIndex].value)\">\n";
  while ($abt_row = db_fetch_row($abt_res)) {echo "<option value=\"$abt_row[0]\">$abt_row[1]</option>\n";}
  echo "</select></td>\n<td>$admin_3</td>\n<td><select name=nartgr>\n";
  while ($artgr_row = db_fetch_row($artgr_res)) {echo "<option value=\"$artgr_row[0]\">$artgr_row[1]</option>\n";}
  echo "</select></td></tr><tr><td colspan=4 align=center><input type=submit value=\"$admin_33\">\n";
  echo "<br><br><hr></td></tr></table>\n</form>\n";
  include ("combo_select.inc.php");
}
elseif ($chg=="edit" || $chg=="copy" || $chg=="quickedit") {
  if ($chg=="quickedit") {
    $quick_res = db_query("select ID from item where number='$art_nr'") or db_die();
    $quick_row = db_fetch_row($quick_res);
    $art = $quick_row[0];
    $chg = "edit";
  }
  $art_res = db_query("select * from item where item.ID='$art'") or db_die();
  $art_row = db_fetch_row($art_res);
  $artgr_res_this = db_query("select itemgr.abtID, itemgr.ID, itemgrinfo.name from itemgr, itemgrinfo where itemgr.ID = itemgrinfo.itemgrID and itemgr.ID='$art_row[2]' and itemgrinfo.langID='$langID'") or db_die();
  $artgr_row_this = db_fetch_row($artgr_res_this);
  $abt_res_this = db_query("select abt.ID, abtinfo.name from abt, abtinfo where abt.ID='$artgr_row_this[0]' and abtinfo.abtID='$artgr_row_this[0]' and abtinfo.langID='$langID'") or db_die();
  $abt_row_this = db_fetch_row($abt_res_this);
  $artgr_res = db_query("select itemgr.ID, itemgrinfo.name from itemgr, itemgrinfo where itemgr.ID = itemgrinfo.itemgrID and itemgr.abtID='$abt_row_this[0]' and itemgrinfo.langID='$langID'") or db_die();
  $abt_res = db_query("select abt.ID, abtinfo.name from abt, abtinfo where abt.ID = abtinfo.abtID and abtinfo.langID='$langID'") or db_die();
  $cur_res = db_query("select * from currency") or db_die();
  echo "<form action=\"$url\" enctype=\"multipart/form-data\" method=\"post\">\n";
  echo "<input type=hidden name=langID value=\"$langID\">\n";
  echo "<input type=hidden name=startlimit value=\"$startlimit\">\n";
  echo "<input type=hidden name=sort value=\"$sort\">\n";
  echo "<table border=0 cellpadding=6 cellspacing=2 align=center>\n";
  echo "<tr valign=top>\n";
  echo "<td>$item_1</td><td colspan=2><input type=text name=\"nart_nr\"\n";
  if ($chg=="edit") { echo " value=\"$art_row[1]\"></td><td>[ $curr_1 $art ]"; }
  else {echo "><td>&nbsp;";}
  echo "</td><tr>\n";
  $autofill=4;
  $lang_res = db_query("select ID,shortt from language order by ID") or db_die();
  while ($lang_row = db_fetch_row($lang_res)) {
    $artinfo_res = db_query("select name,longdescr from iteminfo where iteminfo.itemID='$art' and langID='$lang_row[0]'") or db_die();
    $artinfo_row = db_fetch_row($artinfo_res);
    echo "<tr><td>$item_2 [$lang_row[1]]</td><td colspan=3><input type=text name=\"nname[]\" value=\"$artinfo_row[0]\" size=\"30\">\n";
    if ($autofill==4) {
      echo "<a href=\"javascript:autofill($autofill)\">autofill</a>\n";
      echo "&nbsp;&nbsp;&nbsp;<a href=\"help.php?langID=$langID#autofill\" target=\"besite\"><img src=\"help.gif\" border=0 align=\"absmiddle\"></a>\n";
    }
    echo "</td>\n";
    echo "</tr>\n";
    echo "<tr><td>$item_3 [$lang_row[1]]";
    if ($lang_row[0]==1) {
      echo " <a href=\"help.php?langID=$langID#dynsess\" target=\"besite\"><img src=\"help.gif\" border=0 align=\"absmiddle\"></a>\n";
    }
    echo "</td><td colspan=3><textarea  cols=\"60\" rows=\"4\" name=\"nlongdescr[]\">$artinfo_row[1]</textarea></td></tr>\n";
    $autofill=$autofill+2;
  }

  echo "<tr><td>$item_4</td><td colspan=3><input type=text name=nkeyw value=\"$art_row[3]\" size=60>\n";
  echo "<a href=\"help.php?langID=$langID#keywords\" target=\"besite\"><img src=\"help.gif\" border=0 align=\"absmiddle\"></a></td></tr>\n";

  #Anzeige des gespeicherten nettopreises--------
    $price_res3=db_query("select price.value from price where itemID='$art_row[0]'") or db_die();
    $price_row3=db_fetch_row($price_res3);
    if ($lang=="de")
    $nettopreis_gespeichtert=number_format((round(($price_row3[0]),2)),2,",",".");
    else
    $nettopreis_gespeichtert=number_format((round(($price_row3[0]),2)),2);
    echo "<tr><td>price netto";
    echo "</td><td>$nettopreis_gespeichtert $cur_row[1]\n";
    echo "</td>";
  #Anzeige des gespeicherten Bruttopreises--------
    $price_res2=db_query("select price.value from price where itemID='$art_row[0]'") or db_die();
    $price_row2=db_fetch_row($price_res2);
    $pt_res2 = db_query("select vat from pricetype where ID='$art_row[11]'") or db_die();
    $pt_row2 = db_fetch_row($pt_res2);
    if ($lang=="de")
    $Bruttopreis_gespeichtert=number_format((round(($price_row2[0]*$pt_row2[0]),2)),2,",",".");
    else
    $Bruttopreis_gespeichtert=number_format((round(($price_row2[0]*$pt_row2[0]),2)),2);
    echo "<td>price brutto";
    echo "</td><td>$Bruttopreis_gespeichtert $cur_row[1]\n";
    echo "</td>";

  while ($cur_row = db_fetch_row($cur_res)) {
    $price_res=db_query("select price.value from price where curID='$cur_row[0]' and price.itemID='$art_row[0]'") or db_die();
    $price_row=db_fetch_row($price_res);
    echo "<tr><td>";
    if ($cur_row[0]==1) {
      echo "$item_5&nbsp;&nbsp;&nbsp;";
      echo "<a href=\"help.php?langID=$langID#price\" target=\"besite\"><img src=\"help.gif\" border=0 align=\"absmiddle\"></a>\n";
    }
    echo "</td><td colspan=3><input type=text name=npreis[] value=\"";
    if ($lang=="de") echo number_format($price_row[0],2,",","")."\" size=9>\n"; # german number_format :-(
    else echo number_format($price_row[0],2,".","")."\" size=9>\n"; # english number_format
    echo "<input type=hidden name=db_preis[] value=\"$price_row[0]\">\n";
    echo "<input type=hidden name=ncurID[] value=\"$cur_row[0]\">$cur_row[1]\n";
    if ($cur_row[0]==1) {
      echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type=checkbox name=\"vatvalue\" value=\"1\">$item_6";
      echo "<select name=\"vat\">\n";
      $pt_res = db_query("select ID, vat from pricetype where vat>1") or db_die();
      while ($pt_row = db_fetch_row($pt_res)) {
        $vat = ($pt_row[1]-1)*100;
        echo "<option value=\"$pt_row[1]\"";
        if ($art_row[11]==$pt_row[0]) {echo "selected";}
        echo ">$vat %</option>\n";
      }
    }
    if ($cur_row[0]==2) {
      echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href=\"javascript:autoconvert()\">autoconvert</a>&nbsp;&nbsp;&nbsp;";
      echo "<a href=\"help.php?langID=$langID#autoconvert2\" target=\"besite\"><img src=\"help.gif\" border=0 align=\"absmiddle\"></a>\n";
      echo "<script language=\"JavaScript\">\n";
      $curr2_res = db_query("select rate from currency") or db_die();
      $curr2_len = db_num_rows($curr2_res);
      $lang_len = db_num_rows($lang_res);
      echo "var jscurr_start = 9 + ($lang_len*2);\n";
      echo "var jscurr = new Array($curr2_len);\n";
      $i=0;
      while ($curr2_row = db_fetch_row($curr2_res)) {
        echo "jscurr[$i]=$curr2_row[0];\n";
        $i++;
      }
      echo "function autoconvert() {\n";
      echo "  i=0;\n";
      echo "  jsprvalue= String(document.forms[0].elements[13].value);\n";
      echo "  jsprvalue= jsprvalue.replace(/,/ ,\".\");\n";
      echo "  jscurr_base = Math.round(parseFloat(jsprvalue)*100)/100;\n";
      echo "  for (x=1; x < $curr2_len; x++) {\n";
      echo "    w = jscurr_start +i;\n";
      echo "    jscv = Math.round(jscurr_base * jscurr[x]*100)/100;\n";
      echo "    document.forms[0].elements[w].value = jscv;\n";
      echo "    i=i+2;\n";
      echo "  }\n}\n";
      echo "</script>\n";
    }
    echo "</td></tr>\n";
  }
  $art_row6 = preg_replace("([.][0]{1,}$)","",$art_row[6]);
  echo "<tr><td>$item_7</td><td><input typ=text name=nquanti value=\"$art_row6\" size=6>&nbsp;\n";
  echo "<select name=\"npackID\">\n";
  $pack_res = db_query("select package.ID, packinfo.name from package, packinfo where packinfo.langID='$langID' and package.ID = packinfo.packID order by name") or db_die();
  while ($pack_row = db_fetch_row($pack_res)) {
    echo "<option value='$pack_row[0]'";
    if ($pack_row[0]==$art_row[10]) {echo " selected";}
    echo ">$pack_row[1]</option>\n";
  }
  echo "</select></td>\n";
  echo "<td>Mehrwertsteuergruppe</td>\n";
  echo "<td><select name=\"nvatID\">\n";
  $pt_res = db_query("select ID, vat from pricetype where vat>1") or db_die();
  while ($pt_row = db_fetch_row($pt_res)) {
    $vat = ($pt_row[1]-1)*100;
    echo "<option value=\"$pt_row[0]\"";
    if ($art_row[11]==$pt_row[0]) {echo "selected";}
    echo ">$vat %</option>\n";
  }
  echo "</td><tr>\n";

  echo "<tr><td>$item_8</td><td><input type=text name=norderby value=\"$art_row[8]\" size=5></td>\n";
  echo "<td>$item_9</td><td><input type=checkbox name=nvisible value=1 ";
  if ($art_row[9]==1) { echo "checked ";}
  echo "></td>\n";
  echo "</tr>\n";

  echo "<tr><td>$item_10</td>\n";
  $size_res = db_query("select stock, expiration from size where size.itemID='$art'") or db_die();
  $size_row = db_fetch_row($size_res);
  $size_num = db_num_rows($size_res) - 1;
  $size_row0 = preg_replace("([.][0]{1,}$)","",$size_row[0]);
  echo "<td><input type=text name=\"nstock\" value=\"$size_row0\" size=10></td>\n";
  echo "<td><select name=\"nexpi\">\n";
  echo "<option value=\"actual\" ";
  if ($size_row[1]=="actual") { echo "selected ";}
  echo ">2-3 Tage</option>\n<option value=\"Xactual\" ";
  if ($size_row[1]=="Xactual") { echo "selected ";}
  echo ">2-3 Wochen</option>\n<option value=\"rest\"";
  if ($size_row[1]=="rest") { echo "selected ";}
  echo ">bis ausverkauft</option>\n<option value=\"never\"";
  if ($size_row[1]=="never") { echo "selected ";}
  echo ">immer</option>\n";
  echo "</select></td>\n";
  echo "<td>\n";

  if ($chg=="edit") {
    echo "<tr><td>$item_16</td>\n";
    echo "<td><a href=\"size.php?itemID=$art&langID=$langID&startlimit=$startlimit\">$item_16</a> [ $size_num ]\n</td>\n";
echo "<td>2. Eigenschaft:\n</td>\n";
    $color_res = db_query("select ID from color where color.itemID='$art'") or db_die();
    $color_num = db_num_rows($color_res);
echo "<td colspan=4><a href=\"color.php?itemID=$art&langID=$langID&startlimit=$startlimit\">2. Eigenschaft anlegen/&auml;ndern</a> [ $color_num ]</td></tr>";
  }

  echo "<tr valign=top><td>$item_14</td><td><input type=\"file\" name=\"npic[]\" accept=\"image/*\">\n";
  if ($art_row[4]) {
    echo "<br>$item_20: $art_row[4]&nbsp;&nbsp;&nbsp;$admin_21<input type=checkbox name=\"picdel0\" value=\"1\"></td>\n";
  }
  echo "<td>$item_15</td><td><input type=\"file\" name=\"npic[]\" accept=\"image/*\">\n";
  if ($art_row[5]) {
    echo "<br>$item_20: $art_row[5]&nbsp;&nbsp;&nbsp;$admin_21<input type=checkbox name=\"picdel1\" value=\"1\"></td>\n";
  }

  echo "<tr><td>$admin_2</td>\n";
  echo "<td><select name=nabt onchange=\"updateArtgr(this.form, this.options[this.selectedIndex].value)\">\n";
  while ($abt_row = db_fetch_row($abt_res)) {
    echo "<option value=\"$abt_row[0]\"";
    if ($abt_row[0]==$abt_row_this[0]) {echo " selected";}
    echo ">$abt_row[1]</option>\n";
  }
  echo "</select></td>\n";
  echo "<td>$admin_3</td>\n";
  echo "<td><select name=nartgr>\n";
  while ($artgr_row = db_fetch_row($artgr_res)) {
    echo "<option value=\"$artgr_row[0]\"";
    if ($artgr_row[0]==$artgr_row_this[1]) {echo " selected";}
    echo ">$artgr_row[1]</option>\n";
  }
  echo "</select></td></tr>\n";
  echo "<tr><td colspan=3>&nbsp;</td><td><a href=it_itgr.php?langID=$langID&itemID=$art>weitere Artikelgruppen</a></td></tr>\n";

  echo "<tr><td colspan=3 align=center>\n";
  if ($chg=="edit") {
    echo "<input type=hidden name=art value=\"$art_row[0]\">\n";
    echo "<input type=hidden name=mode value=\"edit\">\n";
    echo "<input type=submit value=\"$admin_32\">\n";
    echo "</td><td>";
    echo "<a href=\"$url?langID=$langID&startlimit=$startlimit&sort=$sort&mode=del&art=$art_row[0]\">\n";
    echo "<img src=\"delete.gif\" border=0 alt=\"$admin_21\" alt=\"$admin_21\" title=\"$admin_21\"></a>\n";
  }
  else {
    echo "<input type=hidden name=mode value=\"new\">\n";
    echo "<input type=submit value=\"$admin_33\">\n";
    echo "</td><td>&nbsp;";
  }
  echo "</td></tr><tr><td colspan=4><hr></td></tr></table>\n</form>\n";
  include ("combo_select.inc.php");

  echo "<script language=\"JavaScript\">\n";
  echo "function autofill(w) {\n";
  $autofill = $autofill-4;
  echo "  for (langlen=2; langlen<$autofill; langlen=langlen+2) {\n";
  echo "    document.forms[0].elements[w+langlen].value = document.forms[0].elements[w].value;\n";
  echo "  }\n}\n";
  echo "</script>\n";
}
$search_sql = "";
if ($search!="") $search_sql=" AND iteminfo.name LIKE '%$search%' ";

if ($sort=="") { $sort = "item.number"; }
$art_res = db_query("select item.*, iteminfo.*, currency.keysign from item, iteminfo, currency
           where item.ID = iteminfo.itemID and iteminfo.langID='$langID' and currency.keysign='$curr_sym'
           $search_sql
           order by $sort, item.orderby") or db_die();
$num_res = db_num_rows($art_res);
if ($num_res>$view_limit) {
  require("limit_navi.inc.php");
}

echo "<table border=0 cellpadding=6 cellspacing=2 align=center>\n";
echo "<tr><td colspan=2><a href=\"$url?langID=$langID&startlimit=$startlimit&sort=$sort&chg=addnew\">$item_17</a></td>\n";
echo "<td colspan=6 align=\"center\"><form action=\"$url\" method=\"post\">\n";
echo "$item_18&nbsp;&nbsp;<input type=text name=art_nr><input type=hidden name=langID value=\"$langID\">\n";
echo "<input type=hidden name=sort value=\"$sort\"><input type=hidden name=startlimit value=\"$startlimit\">\n";
echo "<input type=hidden name=chg value=\"quickedit\"><input type=submit value=\"$admin_32\">\n";
echo "</td>\n";
echo "<td colspan=3 align=\"center\"><form action=\"$url\" method=\"post\">\n";
echo "$item_2&nbsp;&nbsp;<input type=text name=search size=8><input type=hidden name=langID value=\"$langID\">\n";
echo "<input type=hidden name=sort value=\"$sort\"><input type=hidden name=startlimit value=\"$startlimit\">\n";
echo "<input type=submit value=\"$item_21\">\n";
echo "</td></tr>\n";

echo "<tr valign=\"top\" align=\"center\">\n";
echo "<td><a href=\"$url?langID=$langID&startlimit=$startlimit&sort=item.number\">$item_18</a></td>\n";
echo "<td><a href=\"$url?langID=$langID&startlimit=$startlimit&sort=iteminfo.name\">$item_2</a></td>\n";
echo "<td>&nbsp;</td>\n<td>$item_5 [$curr_sym]</td>\n<td>$admin_2</td>\n";
echo "<td>$admin_3</td>\n";
echo "<td>&nbsp;</td><td>&nbsp;</td></tr>\n";
while ($art_row = db_fetch_row($art_res)) {
  echo "<tr valign=\"top\"><td align=\"right\">\n";
  if ($art_row[9]==0) {echo "<font color=FF0000>!&nbsp;</font>";}
  echo "<a href=\"$url?langID=$langID&startlimit=$startlimit&sort=$sort&chg=edit&art=$art_row[0]\">$art_row[1]</a></td>\n";
  echo "<td>$art_row[15]</td>\n <td>";
  echo snipstr($art_row[16],9);
  echo "&nbsp;</td>\n<td align=\"right\">";
  $price_res=db_query("select price.value from price, currency where currency.keysign='$curr_sym' and currency.ID = price.curID and price.itemID='$art_row[0]'") or db_die();
  $price_row=db_fetch_row($price_res);
  $fprice=number_format($price_row[0],2,",",".");
  echo "$fprice</td>\n";
  $artgr_res = db_query("select itemgr.abtID, itemgrinfo.name from itemgr, itemgrinfo where itemgr.ID = itemgrinfo.itemgrID and itemgr.ID='$art_row[2]' and itemgrinfo.langID='$langID'") or db_die();
  $artgr_row = db_fetch_row($artgr_res);
  $abt_res = db_query("select name from abtinfo where abtinfo.abtID='$artgr_row[0]' and langID='$langID'") or db_die();
  $abt_row = db_fetch_row($abt_res);
  echo "<td>$abt_row[0]</td>\n";
  echo "<td>$artgr_row[1]</td>\n";
  echo "<td><a href=\"$url?langID=$langID&startlimit=$startlimit&sort=$sort&chg=copy&art=$art_row[0]\"><img src=\"copy.gif\" border=0 alt=\"$item_19\"></a></td>\n";
  echo "<td><a href=\"$url?langID=$langID&startlimit=$startlimit&sort=$sort&mode=del&art=$art_row[0]\"><img src=\"delete.gif\" border=0 alt=\"$admin_21\"></a></td></tr>\n";
}

echo "<tr><td colspan=8><a href=\"$url?langID=$langID&chg=addnew\">$item_17</a></td></tr>\n";
echo "</table>\n</body>\n</html>\n";
exit;
?>