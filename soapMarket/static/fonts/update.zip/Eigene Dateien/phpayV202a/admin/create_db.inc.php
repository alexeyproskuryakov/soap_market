<?php

if ($create_database=="yes") {
    // Connect
    if ( $db_type == "mysql" ) {
      $dbIDnull = "null";
      $link = mysql_connect($db_host, $db_user, $db_pass) or mysql_error();
      $conn = mysql_select_db($db_name);
    }
    elseif ( $db_type == "interbase" ) {
      $dbIDnull = "null";
      $db_host2 = "$db_host:$db_name";
      $link = ibase_connect($db_host2, $db_user, $db_pass);
    }
    elseif ( $db_type == "postgresql" ) {
      $dbIDnull = "pgnull";
      $link = pg_connect("$db_host","5432","$db_name") or pg_errormessage();
    }
    elseif ( $db_type == "odbc" ) {
      $dbIDnull = "null";
      $link = odbc_connect($db_name, $db_user, $db_pass);
    }
    elseif ( $db_type == "oracle" ) {
      $dbIDnull = "null";
      $link = OCILogon($db_user, $db_pass, $db_name);
      $datestmt = OCIParse($link, "alter session set NLS_DATE_FORMAT='YYYY-MM-DD HH:MI:SS'");
      OCIExecute($datestmt);
    }
    elseif ( $db_type == "informix" ) {
      $dbIDnull = "0";
      if ($db_host == "") $db = $db_name; else $db = $db_name."@".$db_host;
      $link = ifx_connect($db, $db_user, $db_pass);
    }
    elseif ( $db_type == "ms_sql" ) {
      $dbIDnull = "msnull";
      $link = mssql_connect($db_name, $db_user, $db_pass);
      $conn = mssql_select_db($db_name);
    }
}
#
# Table structure for table `abt`
#
db_query2("DROP TABLE IF EXISTS abt") or db_die2();
db_query2("CREATE TABLE abt (
  ID int(8) unsigned NOT NULL auto_increment,
  orderby int(8) default NULL,
  groupID int(8) NOT NULL default '2',
  picname varchar(35) default NULL,
  newid varchar(32) default NULL,
  PRIMARY KEY  (ID),
  KEY ID (ID)
)") or db_die2();
# --------------------------------------------------------

#
# Table structure for table `abtinfo`
#

db_query2("DROP TABLE IF EXISTS abtinfo") or db_die2();
db_query2("CREATE TABLE abtinfo (
  ID int(8) unsigned NOT NULL auto_increment,
  abtID int(8) NOT NULL default '1',
  langID int(8) NOT NULL default '1',
  name varchar(25) NOT NULL default '',
  text text NOT NULL,
  PRIMARY KEY  (ID),
  KEY ID (ID)
)") or db_die2();
# --------------------------------------------------------

#
# Table structure for table `cart`
#

db_query2("DROP TABLE IF EXISTS cart") or db_die2();
db_query2("CREATE TABLE cart (
  ID int(8) NOT NULL auto_increment,
  session varchar(32) default NULL,
  itemID int(8) NOT NULL default '0',
  quantity decimal(10,3) unsigned NOT NULL default '1.000',
  sizeID int(8) NOT NULL default '0',
  colorID int(8) NOT NULL default '0',
  PRIMARY KEY  (ID),
  KEY ID (ID)
)") or db_die2();
# --------------------------------------------------------

#
# Table structure for table `currency`
#

db_query2("DROP TABLE IF EXISTS currency") or db_die2();
db_query2("CREATE TABLE currency (
  ID int(4) NOT NULL auto_increment,
  keysign char(3) NOT NULL default '',
  name varchar(50) NOT NULL default '',
  rate decimal(10,6) unsigned NOT NULL default '1.000000',
  div varchar(32) default NULL,
  PRIMARY KEY  (ID),
  KEY ID (ID)
)") or db_die2();
# --------------------------------------------------------

#
# Table structure for table `item`
#

db_query2("DROP TABLE IF EXISTS item") or db_die2();
db_query2("CREATE TABLE item (
  ID int(8) unsigned NOT NULL auto_increment,
  number varchar(16) NOT NULL default '',
  itemgrID int(8) unsigned NOT NULL default '1',
  keywords varchar(150) default NULL,
  picname1 varchar(50) default NULL,
  picname2 varchar(50) default NULL,
  quantity decimal(10,3) unsigned NOT NULL default '1.000',
  newid varchar(32) NOT NULL default '1',
  orderby int(8) default NULL,
  visible tinyint(1) NOT NULL default '1',
  packID int(8) NOT NULL default '1',
  vatID int(8) NOT NULL default '2',
  PRIMARY KEY  (ID))") or db_die2();
# --------------------------------------------------------

#
# Table structure for table `itemgr`
#

db_query2("DROP TABLE IF EXISTS itemgr") or db_die2();
db_query2("CREATE TABLE itemgr (
  ID int(8) unsigned NOT NULL auto_increment,
  orderby int(8) default '0',
  abtID int(8) unsigned NOT NULL default '1',
  groupID int(8) unsigned NOT NULL default '2',
  newid varchar(32) default NULL,
  PRIMARY KEY  (ID)
)") or db_die2();
# --------------------------------------------------------

#
# Table structure for table `itemgrinfo`
#

db_query2("DROP TABLE IF EXISTS itemgrinfo") or db_die2();
db_query2("CREATE TABLE itemgrinfo (
  ID int(8) unsigned NOT NULL auto_increment,
  itemgrID int(8) NOT NULL default '1',
  langID int(8) NOT NULL default '1',
  name varchar(20) NOT NULL default '',
  div tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (ID),
  KEY ID (ID)
)") or db_die2();
# --------------------------------------------------------

#
# Table structure for table `iteminfo`
#

db_query2("DROP TABLE IF EXISTS iteminfo") or db_die2();
db_query2("CREATE TABLE iteminfo (
  ID int(8) unsigned NOT NULL auto_increment,
  itemID int(8) unsigned NOT NULL default '1',
  langID int(8) unsigned NOT NULL default '1',
  name varchar(30) NOT NULL default '',
  keywords varchar(50) default NULL,
  longdescr text,
  div0 tinyint(1) default NULL,
  PRIMARY KEY  (ID),
  KEY ID (ID)
)") or db_die2();
# --------------------------------------------------------

#
# Table structure for table `language`
#

db_query2("DROP TABLE IF EXISTS language") or db_die2();
db_query2("CREATE TABLE language (
  ID int(8) NOT NULL auto_increment,
  shortt char(2) NOT NULL default '',
  longt varchar(15) NOT NULL default '',
  picname varchar(20) NOT NULL default 'filler.gif',
  PRIMARY KEY  (ID)
)") or db_die2();
# --------------------------------------------------------

#
# Table structure for table `link`
#

db_query2("DROP TABLE IF EXISTS link") or db_die2();
db_query2("CREATE TABLE link (
  ID int(8) NOT NULL auto_increment,
  langID int(8) NOT NULL default '0',
  orderby smallint(4) NOT NULL default '0',
  url varchar(150) NOT NULL default '',
  target varchar(15) NOT NULL default 'main',
  name varchar(50) NOT NULL default 'link',
  PRIMARY KEY  (ID)
)") or db_die2();
# --------------------------------------------------------

#
# Table structure for table `online`
#

db_query2("DROP TABLE IF EXISTS online") or db_die2();
db_query2("CREATE TABLE online (
  ID int(8) unsigned NOT NULL auto_increment,
  user_ID int(8) NOT NULL default '2',
  user_pw varchar(32) NOT NULL default '',
  session varchar(32) default NULL,
  config varchar(20) NOT NULL default '',
  ltime varchar(14) default NULL,
  ip varchar(15) default NULL,
  langID int(8) default NULL,
  curID int(8) NOT NULL default '1',
  acturl varchar(50) default NULL,
  itemgrID int(8) default NULL,
  PRIMARY KEY  (ID),
  KEY ID (ID)
)") or db_die2();
# --------------------------------------------------------

#
# Table structure for table `package`
#

db_query2("DROP TABLE IF EXISTS package") or db_die2();
db_query2("CREATE TABLE package (
  ID int(8) NOT NULL auto_increment,
  newid varchar(32) NOT NULL default '',
  div0 tinyint(1) default NULL,
  div1 tinyint(1) default NULL,
  PRIMARY KEY  (ID),
  KEY ID (ID)
)") or db_die2();
# --------------------------------------------------------

#
# Table structure for table `packinfo`
#

db_query2("DROP TABLE IF EXISTS packinfo") or db_die2();
db_query2("CREATE TABLE packinfo (
  ID int(8) NOT NULL auto_increment,
  packID int(8) NOT NULL default '0',
  langID int(8) NOT NULL default '1',
  name varchar(32) NOT NULL default '',
  PRIMARY KEY  (ID)
)") or db_die2();
# --------------------------------------------------------

#
# Table structure for table `payment`
#

db_query2("DROP TABLE IF EXISTS payment") or db_die2();
db_query2("CREATE TABLE payment (
  ID int(8) NOT NULL auto_increment,
  name varchar(30) default NULL,
  pluscost decimal(4,2) NOT NULL default '0.00',
  langID int(8) NOT NULL default '0',
  formfile varchar(50) NOT NULL default '',
  PRIMARY KEY  (ID),
  KEY ID (ID)
)") or db_die2();
# --------------------------------------------------------

#
# Table structure for table `price`
#

db_query2("DROP TABLE IF EXISTS price") or db_die2();
db_query2("CREATE TABLE price (
  ID int(8) unsigned NOT NULL auto_increment,
  itemID int(8) unsigned NOT NULL default '0',
  langID int(8) unsigned NOT NULL default '1',
  curID int(8) NOT NULL default '1',
  pricetypeID int(8) NOT NULL default '1',
  value decimal(20,6) NOT NULL default '0.00',
  PRIMARY KEY  (ID),
  KEY ID (ID)
)") or db_die2();
# --------------------------------------------------------

#
# Table structure for table `pricetype`
#

db_query2("DROP TABLE IF EXISTS pricetype") or db_die2();
db_query2("CREATE TABLE pricetype (
  ID int(8) NOT NULL auto_increment,
  type varchar(5) NOT NULL default '',
  description varchar(30) default NULL,
  vat decimal(6,4) NOT NULL default '0.0000',
  PRIMARY KEY  (ID),
  KEY ID (ID)
)") or db_die2();
# --------------------------------------------------------

#
# Table structure for table `shipment`
#

db_query2("DROP TABLE IF EXISTS shipment") or db_die2();
db_query2("CREATE TABLE shipment (
  ID int(8) NOT NULL auto_increment,
  name varchar(30) NOT NULL default '',
  costs decimal(8,2) NOT NULL default '0.00',
  langID int(8) NOT NULL default '1',
  formfile varchar(50) NOT NULL default '',
  PRIMARY KEY  (ID),
  KEY ID (ID)
)") or db_die2();
# --------------------------------------------------------

#
# Table structure for table `user`
#

db_query2("DROP TABLE IF EXISTS user") or db_die2();
db_query2("CREATE TABLE user (
  ID int(8) NOT NULL auto_increment,
  firstname varchar(40) NOT NULL default '',
  name varchar(40) NOT NULL default '',
  pw varchar(40) NOT NULL default '',
  groupID int(8) unsigned NOT NULL default '2',
  email varchar(60) NOT NULL default '',
  langID int(8) NOT NULL default '1',
  kdnr int(10) NOT NULL default '0',
  street varchar(75) default NULL,
  hnr varchar(5) default NULL,
  plz varchar(10) default NULL,
  city varchar(50) default NULL,
  country varchar(20) default NULL,
  firma varchar(50) default NULL,
  memo text,
  PRIMARY KEY  (ID),
  KEY kdnr_2 (kdnr),
  KEY ID (ID)
)") or db_die2();
# --------------------------------------------------------

#
# Table structure for table `usrgroup`
#

db_query2("DROP TABLE IF EXISTS usrgroup") or db_die2();
db_query2("CREATE TABLE usrgroup (
  ID int(8) NOT NULL auto_increment,
  name varchar(20) NOT NULL default '',
  bn tinyint(1) NOT NULL default '2',
  description varchar(255) default NULL,
  picname varchar(50) default NULL,
  textfile varchar(50) default NULL,
  discount decimal(6,3) NOT NULL default '0.000',
  PRIMARY KEY  (ID),
  KEY ID (ID)
)") or db_die2();

#-----------------------------------------------
#
# Tabellenstruktur f&uuml;r Tabelle `characteristic`
#

db_query2("DROP TABLE IF EXISTS characteristic") or db_die2();
db_query2("CREATE TABLE characteristic (
  ID int(8) NOT NULL auto_increment,
  aktiv int(8) NOT NULL default '1',
  value varchar(50) NOT NULL default '',
  orderby int(8) default NULL,
  newid varchar(32) default NULL,
  PRIMARY KEY  (ID),
  KEY ID (ID)
)") or db_die2();
# --------------------------------------------------------

#
# Tabellenstruktur f&uuml;r Tabelle `characteristicinfo`
#

db_query2("DROP TABLE IF EXISTS characteristicinfo") or db_die2();
db_query2("CREATE TABLE characteristicinfo (
  ID int(8) unsigned NOT NULL auto_increment,
  characteristicID int(8) default NULL,
  langID int(8) NOT NULL default '1',
  name varchar(25) NOT NULL default '',
  text text NOT NULL,
  orderby int(8) default NULL,
  PRIMARY KEY  (ID),
  KEY ID (ID)) ") or db_die2();
# --------------------------------------------------------

#
# Tabellenstruktur f&uuml;r Tabelle `color`
#

db_query2("DROP TABLE IF EXISTS color") or db_die2();
db_query2("CREATE TABLE color (
  ID int(8) NOT NULL auto_increment,
  itemID int(8) NOT NULL default '0',
  stock decimal(10,3) NOT NULL default '1.000',
  expiration varchar(10) NOT NULL default 'never',
  newid varchar(32) NOT NULL default '0',
  aktiv int(8) NOT NULL default '1',
  orderby int(8) default NULL,
  PRIMARY KEY  (ID)
)") or db_die2();
# --------------------------------------------------------

#
# Tabellenstruktur f&uuml;r Tabelle `colorinfo`
#

db_query2("DROP TABLE IF EXISTS colorinfo") or db_die2();
db_query2("CREATE TABLE colorinfo (
  ID int(8) NOT NULL auto_increment,
  colorID int(8) NOT NULL default '1',
  langID int(8) NOT NULL default '1',
  value varchar(50) NOT NULL default '',
  text text NOT NULL,
  orderby int(8) default NULL,
  PRIMARY KEY  (ID),
  KEY ID (ID)
)") or db_die2();
# --------------------------------------------------------

#
# Tabellenstruktur f&uuml;r Tabelle `size`
#

db_query2("DROP TABLE IF EXISTS size") or db_die2();
db_query2("CREATE TABLE size (
  ID int(8) NOT NULL auto_increment,
  itemID int(8) NOT NULL default '0',
  stock decimal(10,3) NOT NULL default '1.000',
  expiration varchar(10) NOT NULL default 'never',
  newid varchar(32) NOT NULL default '0',
  aktiv int(8) NOT NULL default '1',
  orderby int(8) default NULL,
  PRIMARY KEY  (ID)
)") or db_die2();
# --------------------------------------------------------

#
# Tabellenstruktur f&uuml;r Tabelle `sizeinfo`
#

db_query2("DROP TABLE IF EXISTS sizeinfo") or db_die2();
db_query2("CREATE TABLE sizeinfo (
  ID int(8) NOT NULL auto_increment,
  sizeID int(8) NOT NULL default '1',
  langID int(8) NOT NULL default '1',
  value varchar(50) NOT NULL default '',
  text text NOT NULL,
  orderby int(8) default NULL,
  PRIMARY KEY  (ID),
  KEY ID (ID)
)") or db_die2();

db_query2("DROP TABLE IF EXISTS it_itgr") or db_die2();
db_query2("CREATE TABLE it_itgr (
 ID INT(8) NOT NULL AUTO_INCREMENT,
 itemID INT(8) NULL,
 itemgrID INT(8) NULL,
  PRIMARY KEY  (ID),
)") or db_die2();

#
# Table structure for table `bestell`
#

db_query2("DROP TABLE IF EXISTS bestell") or db_die2();
db_query2("CREATE TABLE bestell (
  ID int(8) NOT NULL auto_increment,
  userID int(8) NOT NULL default '2',
  curID int(8) NOT NULL default '1',
  ltime varchar(32) NOT NULL default '',
  stat varchar(10) NOT NULL default 'neu',
  rate decimal(10,6) NOT NULL default '1.000000',
  newid varchar(32) NOT NULL default '',
  paym text NOT NULL,
  pm_price decimal(4,2) NOT NULL default '0.00',
  shipm text NOT NULL,
  sm_price decimal(4,2) NOT NULL default '0.00',
  partnerID int(8) NOT NULL default '1',
  number int(11) NOT NULL default '0',
  provi decimal(5,2) NOT NULL default '0.00',
  bill_date varchar(14) default NULL,
  sent_date varchar(14) default NULL,
  rem_date varchar(14) default NULL,
  message text,
  PRIMARY KEY  (ID)
)") or db_die2();
# --------------------------------------------------------

#
# Table structure for table `bestellstart`
#

db_query2("DROP TABLE IF EXISTS bestellstart") or db_die2();
db_query2("CREATE TABLE bestellstart (
  ID int(11) NOT NULL auto_increment,
  newid varchar(14) NOT NULL default '0',
  PRIMARY KEY  (ID)
)") or db_die2();
# --------------------------------------------------------

#
# Table structure for table `statistics`
#

db_query2("DROP TABLE IF EXISTS statistics") or db_die2();
db_query2("CREATE TABLE statistics (
  ID int(8) NOT NULL auto_increment,
  orderID int(8) NOT NULL default '0',
  item_number varchar(16) NOT NULL default '',
  item_name varchar(30) NOT NULL default '',
  size_value varchar(50) NOT NULL default '',
  color_value varchar(50) NOT NULL default '',
  quantity decimal(10,3) NOT NULL default '0.000',
  price_value decimal(20,6) NOT NULL default '0.000000',
  vat decimal(6,4) NOT NULL default '1.1600',
  PRIMARY KEY  (ID)
)") or db_die2();

db_query2("INSERT INTO it_itgr VALUES ('1', '0', '0')") or db_die2();
db_query2("INSERT INTO currency VALUES (1, 'EUR', 'Euro', '1.000000',  '' )") or db_die2();
db_query2("INSERT INTO currency VALUES (2, 'USD', 'American Dollars', '1.057',  '')") or db_die2();

db_query2("INSERT INTO language VALUES (1, 'de', 'Deutsch', 'de.gif')") or db_die2();
db_query2("INSERT INTO language VALUES (2, 'en', 'english', 'en.gif')") or db_die2();
db_query2("INSERT INTO language VALUES (3, 'es', 'espa&ntilde;ol', 'es.gif')") or db_die2();
db_query2("INSERT INTO language VALUES (4, 'da', 'dansk', 'da.gif')") or db_die2();
db_query2("INSERT INTO language VALUES (5, 'fr', 'francais', 'fr.gif')") or db_die2();
db_query2("INSERT INTO language VALUES (6, 'nl', 'dutch', 'nl.gif')") or db_die2();

db_query2("INSERT INTO link VALUES (1, 1, 1, 'credits.html', 'main', 'Credits')") or db_die2();

db_query2("INSERT INTO package VALUES (1, '2458435763', '0', '0')") or db_die2();
db_query2("INSERT INTO package VALUES (2, '1841971995', '0', '0')") or db_die2();
db_query2("INSERT INTO package VALUES (3, '2302823028', '0', '0')") or db_die2();

db_query2("INSERT INTO packinfo VALUES (1, 1, 1, '')") or db_die2();
db_query2("INSERT INTO packinfo VALUES (2, 1, 2, '')") or db_die2();
db_query2("INSERT INTO packinfo VALUES (3, 1, 3, '')") or db_die2();
db_query2("INSERT INTO packinfo VALUES (4, 2, 1, 'Stk.')") or db_die2();
db_query2("INSERT INTO packinfo VALUES (5, 2, 2, 'pcs.')") or db_die2();
db_query2("INSERT INTO packinfo VALUES (6, 2, 3, 'St�ck')") or db_die2();
db_query2("INSERT INTO packinfo VALUES (18, 3, 3, 'kg')") or db_die2();
db_query2("INSERT INTO packinfo VALUES (17, 3, 2, 'kg')") or db_die2();
db_query2("INSERT INTO packinfo VALUES (16, 3, 1, 'kg')") or db_die2();

db_query2("INSERT INTO payment VALUES (1, 'bar', '0.00', 1, '')") or db_die2();
db_query2("INSERT INTO payment VALUES (2, 'Rechnung', '0.00', 1, '')") or db_die2();
db_query2("INSERT INTO payment VALUES (3, 'Kreditkarte', '0.00', 1, 'form_kreditkarte.php')") or db_die2();
db_query2("INSERT INTO payment VALUES (4, 'Creditcard', '0.00', 0, 'form_creditcard.php')") or db_die2();
db_query2("INSERT INTO payment VALUES (5, 'Nachname', '5.00', 0, '')") or db_die2();

db_query2("INSERT INTO pricetype VALUES (1, 'EVP', 'Nettopreis', '1.0000')") or db_die2();
db_query2("INSERT INTO pricetype VALUES (2, 'UVP1', 'Bruttopreis1', '1.1600')") or db_die2();
db_query2("INSERT INTO pricetype VALUES (3, 'UVP2', 'Bruttopreis2', '1.0700')") or db_die2();

db_query2("INSERT INTO shipment VALUES (1, 'Postpaket', '6.90', 1,'form_dpag.php')") or db_die2();
db_query2("INSERT INTO shipment VALUES (2, '--', '2.00', 2,'')") or db_die2();
db_query2("INSERT INTO shipment VALUES (3, 'UPS', '25.00', 0,'form_dpag.php')") or db_die2();
db_query2("INSERT INTO shipment VALUES (4, 'Selbstabholer', '25.00', 1,'form_selbst.htm')") or db_die2();
db_query2("INSERT INTO shipment VALUES (5, 'Pick up', '0.00', 2,'for_selbst.htm')") or db_die2();

db_query2("INSERT INTO user VALUES (2, 'user', 'public', '4c9184f37cff01bcdc32dc486ec36961', 2, '', 1, '2', '', '', '', '', '', '', '�ffentlicher Benutzer. Wenn das Pa�wort hier ge�ndert wird, mu� es auch in start.php eingetragen werden. Dummy for public access. If password changed here, also edit in start.php.')") or db_die2();
db_query2("INSERT INTO usrgroup VALUES (2, 'public area', 1, 'demo', 'filler.gif', 'public.txt', '0.000')") or db_die2();
db_query2("INSERT INTO usrgroup VALUES (1, 'administration', 1, '', 'filler.gif', 'root.txt', '0.000')") or db_die2();
db_query2("INSERT INTO usrgroup VALUES (7, 'special', 2, 'Test', '', '', '10.000')") or db_die2();

echo " Done :-)</center><br>\n";
?>
