<?php
if (ereg("functions.inc.php", $SCRIPT_NAME)) header("Location:./index.html");
elseif (ereg("functions.inc.php", $_SERVER['SCRIPT_NAME'])) header("Location:./index.html");
function snipstr($string,$len) {
  $sessionID_str = "sess=".$sess;
  $string = ereg_replace("(#sessionID#)",$sessionID_str,$string);
  $tok = strtok ($string," ");
  $i = 0;
  $snippsel = "";
  while ($tok && $i<$len) {
    $snippsel = $snippsel." ".$tok;
    $tok = strtok (" ");
    $i++;
  }
  if (substr_count($string," ")>$len) { $snippsel = $snippsel."&nbsp;...";}
  return $snippsel;
}
function showprice($itemID, $sess) {
    include("lib.inc.php");
    $itemvatID=db_query("select vatID from item where ID='$itemID'") or db_die();
    $itemvatID_row=db_fetch_row($itemvatID);
    $vat_res = db_query("select pricetype.vat from pricetype,item where pricetype.ID='$itemvatID_row[0]'") or db_die();
    $vat_row = db_fetch_row($vat_res);
    $vat = $vat_row[0];
    $price_res = db_query("select price.value,currency.rate,currency.keysign from price,currency
                             where price.itemID='$itemID' AND price.curID=currency.ID AND curID='$curID'") or db_die();
    $price_row = db_fetch_row($price_res);
    if ($curID>1 && $auto_convert=="1") {
      $basis_res = db_query("select price.value from price
                             where price.itemID='$itemID' AND price.curID='1'") or db_die();
      $basis_row = db_fetch_row($basis_res);
      $price_row[0] = $price_row[1] * $basis_row[0];
    }

    $disprice = ($price_row[0]-($price_row[0]*$user_disc));

    if ($user_pt==1) { $disprice=$disprice*$vat;}; # includes VAT

    if ($lang=="de") {$price= number_format($disprice, 2 , "," , ".");}
    else {$price = number_format($disprice , 2 , "." , ",");}
    if (($price_row[0] == 0) AND ($show_null == 0)) {$price = $null_text;}
    elseif ($price_row[0] < 0) { $price = $gratis;}
    else { $price = $price."&nbsp;".$price_row[2];}
    return $price;
}
function pm_price($ID, $curID) {
    $price_res = db_query("select pluscost from payment where ID='$ID'") or db_die();
    $price_row = db_fetch_row($price_res);

    $acurr_res = db_query("select ID, rate, keysign from currency where ID='$curID'") or db_die();
    $acurr_row = db_fetch_row($acurr_res);
    $price = $price_row[0] * $acurr_row[1];

    if ($lang=="de") {$price= number_format($price, 2 , "," , ".");}
    else {$price = number_format($price , 2 , "." , ",");}
    return $price;
}
function sm_price($ID, $curID) {
    $price_res = db_query("select costs from shipment where ID='$ID'") or db_die();
    $price_row = db_fetch_row($price_res);

    $acurr_res = db_query("select ID, rate, keysign from currency where ID='$curID'") or db_die();
    $acurr_row = db_fetch_row($acurr_res);
    $price = $price_row[0] * $acurr_row[1];

    if ($lang=="de") {$price= number_format($price, 2 , "," , ".");}
    else {$price = number_format($price , 2 , "." , ",");}
    return $price;
}
function frmtprice($ufprice, $sess) {
    include("lib.inc.php");
    if ($lang=="de") {$fprice= number_format($ufprice, 2 , "," , ".");}
    else {$fprice = number_format($ufprice , 2 , "." , ",");}
    if (($ufprice == 0) AND ($show_null == 0)) {$fprice = $null_text;}
    elseif ($ufprice < 0) { $fprice = $gratis;}
    else { $fprice = $fprice." ".$cursym; }
    return $fprice;
}
function crypt_nr($timestamp,$nr)
{
  $ord_date = date("y",$timestamp);
  $nummer = $ord_date.sprintf("%04d",$nr);
  return $nummer;
}
function encrypt_nr($nummer)
{
  $order_number = substr($nummer,2);
  $ret_arr = array("nr"=>$order_number, "timestamp"=>$order_ltime_s);
  return $ret_arr;
}
function build_dropdown($content, $name, $selected="", $js = "")
{
  ## Described in 'NittyGritty-PHP' by Addison Wesley 2003
  echo "\n<select name=\"$name\" $js>\n";
  if (is_array($content))
  {
    if (is_array(reset($content)))
    {
      foreach($content as $c)
      {
        echo "  <option value=\"$c[0]\"";
        if ($c[0]==$selected) { echo " selected"; }
        array_shift($c);
        $c_text = implode(" ", $c);
        echo ">$c_text</option>\n";
      }
    } // Ende 1. Aufrufm�glichkeit
    else
    {
      while(list($key,$value) = each($content))
      {
      	echo "  <option value=\"$key\"";
        if ($key==$selected) { echo " selected"; }
        echo ">$value</option>\n";
      }
    }
  }
  elseif (is_dir($content))
  {
    $handle = opendir($content);
    while ($file = readdir ($handle))
    {
      if (is_dir($file) && is_writable($file))
      {
        echo "  <option>$file/</option>\n";
      }
    }
    closedir($handle);
  }
  else
  {
    $res = db_query($content) or db_die();
    while ($row = db_fetch_row($res))
    {
      echo "  <option value=\"$row[0]\"";
      if ($row[0]==$selected) { echo " selected"; }
      array_shift($row);
      $row_text = implode(" ", $row);
      echo ">$row_text</option>\n";
    }
  }
  echo "</select>\n";
}


if (!function_exists('array_sum')):
 function array_sum($src_arr)
 {
 $ret_value = 0;
 foreach ($src_arr as $sv)
 {
 $ret_value += $sv;
 }
 return $ret_value;
 }
endif; 

$functions_loaded=1;
?>
