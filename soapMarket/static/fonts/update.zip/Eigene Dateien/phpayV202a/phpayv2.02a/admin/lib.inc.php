<?
$result = db_query("select user_ID, user_pw, langID, config, curID from online where session='$sess'") or db_die();
$row = db_fetch_row($result);

$config = $row[3];

$langID = $row[2];
if (!$langID) { $langID = 1; }
$lang_res = db_query("select shortt from language where ID='$langID'") or db_die();
$lang_row = db_fetch_row($lang_res);
$lang = $lang_row[0];
if ($lang == "") { $lang = $default_lang; }
include("lang/".$lang.".inc.php");

$curID = $row[4];
$cur_res = db_query("select keysign from currency where ID='$curID'") or db_die();
$cur_row = db_fetch_row($cur_res);
$cursym = $cur_row[0];

$result2 = db_query("select * from user where kdnr='$row[0]' and pw='$row[1]'") or db_die();
$row2 = db_fetch_row($result2);
$user_ID = $row2[0];
$user_firstname = $row2[1];
$user_name = $row2[2];
$md_pw= $row2[3];
$user_group = $row2[4];
$user_email = $row2[5];
$user_kdnr = $row2[7];

$pricetype_res = db_query("select pricetype.vat, usrgroup.pricetypeID from pricetype,usrgroup where usrgroup.ID='$row2[4]' AND usrgroup.pricetypeID=pricetype.ID") or db_die();
$pricetype_row = db_fetch_row($pricetype_res);
$user_pt = $pricetype_row[0];

$dis_res = db_query("select discount from usrgroup where ID='$user_group'") or db_die();
$dis_row = db_fetch_row($dis_res);
$user_disc = $dis_row[0]/100;
?>
