from google.appengine.ext import webapp
from google.appengine.ext.webapp.util import run_wsgi_app
from google.appengine.api import memcache
from google.appengine.ext import db
from google.appengine.api import urlfetch
import datetime

cache = memcache.Client()

''' 
    load id from memcache by peerid
    if no id - create new db
'''


class p2pUser(db.Model):
    peerid = db.StringProperty(indexed=True);
    roomid = db.StringProperty(indexed=True);
    time = db.DateTimeProperty(indexed=True);
    

def updateUser(peerid, roomid):
    userkey = cache.get('peer%s' % peerid)
    if userkey is None:
        #new user
        user = p2pUser()
        newuser = True
    else:
        user = p2pUser.get(userkey)
        newuser = False
        
    user.peerid = peerid
    user.roomid = roomid
    user.time = datetime.datetime.now()
    userkey = user.put()
    if newuser:
        cache.set('peer%s' % peerid, userkey, 3600)
        
def getPeers(peerid, roomid):
    mintime = datetime.datetime.now() - datetime.timedelta(0, 60)
    q = p2pUser.gql('WHERE roomid = :1 AND time >= :2 ORDER BY time DESC', roomid, mintime)
    peers = []
    for u in q.fetch(100):
        peers.append(u.peerid) 
    if peerid in peers:
        peers.remove(peerid)
    return peers
    
class Index(webapp.RequestHandler):
    def get(self):
        self.redirect('/client/index.html')
    
class FetchRSS(webapp.RequestHandler):
    def get(self):
        text = cache.get('rss')
        if text is None:
            url = "http://habrahabr.ru/rss/"
            result = urlfetch.fetch(url)
            if result.status_code == 200:
                text = result.content
                cache.set('rss', text, 60)
            else:
                text = '<channel><item><title>Welcome to chat</title></item></channel>'
        self.response.headers['Content-Type'] = 'text/xml'
        self.response.out.write(text)   
        
    
class MainPage(webapp.RequestHandler):
    
    
    def get(self):
        peerid = self.request.get('peer')
        roomid = self.request.get('room')
        
        if not peerid or not roomid:
            self.redirect('/client/index.html')
        else:
            updateUser(peerid, roomid)
            peers = getPeers(peerid, roomid)
            out = '<response>'
            for peer in peers:
                out += '<peer>' + peer + '</peer>'
            out += '</response>'
            self.response.headers['Content-Type'] = 'text/xml'
            
            self.response.out.write(out)            
                  


application = webapp.WSGIApplication([('/', Index),
                                      ('/peers.xml', MainPage),
                                      ('/rss.xml', FetchRSS)
                                      ], debug=False)


def main():
    run_wsgi_app(application)

if __name__ == "__main__":
    main()
